import random
import ete3
import scipy.stats
import re
import argparse
import subprocess
from pandas.core.frame import DataFrame
import os
import numpy as np

global csv_list 

def gen_newick(taxa_num):
    taxon_count_model=scipy.stats.uniform(taxa_num+1, 105)
    tree = ete3.PhyloTree()
    tree.populate(int(taxon_count_model.rvs()), random_branches=True)
    current_internal_index = 0
    current_leaf_index = 0
    
    external_branch_model = scipy.stats.gamma(0.5,0.3)
    internal_branch_model = scipy.stats.gamma(0.5,0.3)
    expected_mean_pairwise_divergence = scipy.stats.uniform(0.03,0.2).rvs()

    for node in tree.traverse("preorder"):
        if node.is_leaf():
            node.name = f"taxon{current_leaf_index:d}"
            node.dist = external_branch_model.rvs()
            current_leaf_index += 1
        else:
            node.name = f"node{current_internal_index:d}"
            node.dist = internal_branch_model.rvs()
            current_internal_index += 1


    total_tree_leaves = [ele.name for ele in tree.get_leaves()]
    
    pairwise_divergence_list = []

    for i in range(0, len(total_tree_leaves)-1):
        for j in range(i+1, len(total_tree_leaves)):
            tmp_dist = tree.get_distance(total_tree_leaves[i], total_tree_leaves[j])
            if tmp_dist > 1e-4:
                pairwise_divergence_list.append(tmp_dist)

    mean_pairwise_divergence = np.mean(np.array(pairwise_divergence_list))

    
    scale_ratio = expected_mean_pairwise_divergence / mean_pairwise_divergence 

    for node in tree.traverse("preorder"):
        node.dist = max(0.0001, node.dist*scale_ratio)
        node.dist = format(node.dist, '.4f')


    leaves = random.sample(tree.get_leaves(), taxa_num)
    
    tree.prune(leaves, preserve_branch_length=True)
    tree.unroot()

    ans = tree.write(format=5)
    match = re.findall('taxon\d+:', ans)

    idx = ['0']
    number_set = [i for i in range(1, taxa_num)]

    for i in range(0, taxa_num-1):
        sample_number = random.choice(number_set)
        number_set.remove(sample_number)
        idx.append(str(sample_number))

    for i in range(0, len(match)):
        ans = ans.replace(match[i], idx[i]+':')

    csv_list.append(ans)

parser = argparse.ArgumentParser('get_parameters_of_simulation')
p_input = parser.add_argument_group("INPUT")
p_input.add_argument("--taxa_num", action="store", type=int, required=True)
p_input.add_argument("--num_of_topology", action="store", type=int, required=True)
args = parser.parse_args()
num_of_topology = args.num_of_topology
taxa_num = args.taxa_num

csv_list = []

for i in range(0, num_of_topology):
    gen_newick(taxa_num)

folder_label = '../label_file/'
if not os.path.exists(folder_label):
    os.mkdir(folder_label)

if not os.path.exists('../simulate_data'):
    os.mkdir('../simulate_data')

subprocess.call('cp ../indelible ../simulate_data/indelible',shell=True)
dictionary = {"newick" : csv_list}
data=DataFrame(dictionary)
newick_dir = folder_label + 'newick.csv'
data.to_csv(newick_dir)
tmp_cmd = 'Rscript ./gen_control_file.R {} '.format(str(taxa_num)) + str(num_of_topology) 
retcode = subprocess.call(tmp_cmd,shell=True)
retcode2 = subprocess.call("mv ./control.txt ../simulate_data/control.txt",shell=True)