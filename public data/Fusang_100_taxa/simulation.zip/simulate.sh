#!/bin/bash
#SBATCH -J simulate
#SBATCH -p bioinfo_fat
#SBATCH -n 1 
#SBATCH -c 3
#SBATCH -o simulate.out
#SBATCH -e simulate.err
#SBATCH --mem-per-cpu=5G
module load R/3.6.2
module load gcc
cd ./code
time python simulate_topology.py --taxa_num 100 --num_of_topology 1
cd ../simulate_data
./indelible
cd ../code
time python extract_fasta_data.py
cp ../simulate_data/trees.txt ../label_file/trees.txt
rm -r ../simulate_data